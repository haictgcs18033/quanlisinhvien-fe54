// //Khái niệm đối tượng trong js
// var hocSinh = {
//     maHS:'001',
//     tenHS: 'Nguyễn văn a',
//     xuatThongTinHocSinh: function () {
//         console.log('Mã học sinh',this.maHS);
//         console.log('Tên học sinh',this.tenHS);
//     }
// }
// //Trỏ this trong đối tượng => chính là đối tượng ({})
// //Truy xuất biến trong đối tượng (thuộc tính)
// //Cách 1 [tên_đối_tượng].tenThuocTinh
// console.log(hocSinh.maHS);
// //Cách 2 [tên_đối_tượng]['ten_thuocTinh']
// console.log(hocSinh['tenHS']);
// //Truy xuất hàm trong đối tượng (phương thức)
// //Cách 1: Giống truy xuất thuộc tính nhưng thêm 2 dấu ()
// hocSinh.xuatThongTinHocSinh();
// //Cách 2:
// hocSinh['xuatThongTinHocSinh']();
// console.log('hocSinh',hocSinh);


// -------------------------------------Giải bài tập quản lý sinh viên ---------------

var sinhVien = {
    maSinhVien: '',
    tenSinhVien: '',
    diemToan: '',
    diemLy: '',
    diemHoa: '',
    diemRenLuyen: '',
    loaiSinhVien: '',
    tinhDiemTrungBinh: function () {
        var dtb = (Number(this.diemToan) + Number(this.diemLy) + Number(this.diemHoa)) / 3;
        return dtb;
    },
    xepLoaiSinhVien: function () {
        var diemTrungBinh = this.tinhDiemTrungBinh();

        if (this.diemRenLuyen < 5) {
            return 'Yếu';
        } else if (diemTrungBinh < 5) {
            return 'Yếu';
        } else if (diemTrungBinh >= 5 && diemTrungBinh < 6) {
            return 'Trung bình ';
        } else if (diemTrungBinh >= 6 && diemTrungBinh < 7) {
            return 'Trung bình khá';
        } else if (diemTrungBinh >= 7 && diemTrungBinh < 8) {
            return 'Khá';
        } else if (diemTrungBinh >= 8 && diemTrungBinh < 9) {
            return 'Giỏi';
        } else if (diemTrungBinh >= 9 && diemTrungBinh < 10) {
            return 'Xuất sắc';
        } else {
            return 'Yếu';
        }
    }
}

//Khi người dùng click nút xác nhận => Lấy thông tin người dùng gán vào đối tượng
document.querySelector('#btnXacNhan').onclick = function () {

    //Lấy thông tin người dùng nhập từ giao diện gán vào đối tượng sinh viên
    sinhVien.maSinhVien = document.querySelector('#maSinhVien').value;
    sinhVien.tenSinhVien = document.querySelector('#tenSinhVien').value;
    sinhVien.diemToan = document.querySelector('#diemToan').value;
    sinhVien.diemLy = document.querySelector('#diemLy').value;
    sinhVien.diemHoa = document.querySelector('#diemHoa').value;
    sinhVien.diemRenLuyen = document.querySelector('#diemRenLuyen').value;
    sinhVien.loaiSinhVien = document.querySelector('#loaiSinhVien').value;
    //Kiểm tra giá trị người dùng nhập
    console.log(sinhVien);
    //In thông tin người dùng ra giao diện 
    document.querySelector('.text-maSinhVien').innerHTML = sinhVien.maSinhVien;
    document.querySelector('.text-tenSinhVien').innerHTML = sinhVien.tenSinhVien;
    document.querySelector('.text-loaiSinhVien').innerHTML = sinhVien.loaiSinhVien;
    //Tính điểm trung bình
    var diemTrungBinh = sinhVien.tinhDiemTrungBinh();
    document.querySelector('.text-diemTrungBinh').innerHTML = sinhVien.tinhDiemTrungBinh();

    //Xếp loại sinh viên
    var xepLoai = sinhVien.xepLoaiSinhVien();
    document.querySelector('.text-xepLoai').innerHTML = xepLoai;


    console.log('diemTrungBinh', diemTrungBinh);
}
